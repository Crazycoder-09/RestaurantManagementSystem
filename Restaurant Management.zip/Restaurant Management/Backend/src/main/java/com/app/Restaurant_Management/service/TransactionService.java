package com.app.Restaurant_Management.service;


import com.app.Restaurant_Management.ecxeption.ResourceNotFoundException;
import com.app.Restaurant_Management.entity.TransactionRecord;
import com.app.Restaurant_Management.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    public TransactionRecord saveTransaction(TransactionRecord transaction) {
        transaction.setTransactionDatetime(java.time.LocalDateTime.now());
        return transactionRepository.save(transaction);
    }

    public List<TransactionRecord> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public TransactionRecord getTransactionById(Long id) {
        return transactionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + id));
    }

    public void deleteTransaction(Long id) {
        if (!transactionRepository.existsById(id)) {
            throw new ResourceNotFoundException("Transaction not found with id: " + id);
        }
        transactionRepository.deleteById(id);
    }
}
