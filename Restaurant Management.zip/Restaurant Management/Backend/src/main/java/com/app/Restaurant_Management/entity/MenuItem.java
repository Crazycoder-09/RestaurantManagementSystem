package com.app.Restaurant_Management.entity;

import jakarta.persistence.*;

import javax.print.attribute.standard.MediaSize;

@Entity
@Table(name = "menu_item")
public class MenuItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Long itemId;

    @Column(nullable = false, length = 100)
    private String name;

    private String description;
    private Double price;

    @Enumerated(EnumType.STRING)
    private Category category = Category.Main_Course;

    private Boolean is_available = true;

    @Column(name = "image_url")
    private String imageUrl;

//    public enum Category { APPETIZER, Maincourse, DESSERT, BEVERAGE, OTHER }
    public enum Category { Appetizer, Main_Course, Dessert, Beverage, Other}


    public MenuItem() {
    }

    public MenuItem(Long itemId, String name, String description, Double price, Category category, Boolean is_available,String imageUrl) {
        this.itemId = itemId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.is_available = is_available;
        this.imageUrl=imageUrl;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Boolean getAvailable() {
        return is_available;
    }

    public void setAvailable(Boolean available) {
        is_available = available;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return "MenuItem{" +
                "itemId=" + itemId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", category=" + category +
                ", is_available=" + is_available +
                ",imageUrl="+imageUrl+
                '}';
    }
}

