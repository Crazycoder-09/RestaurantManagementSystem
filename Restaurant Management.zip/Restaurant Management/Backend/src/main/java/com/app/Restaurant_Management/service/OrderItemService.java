package com.app.Restaurant_Management.service;

import com.app.Restaurant_Management.entity.OrderItem;
import com.app.Restaurant_Management.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class OrderItemService {

    @Autowired
    private OrderItemRepository orderItemRepository;

    // ✅ Save a single OrderItem
    public OrderItem saveOrderItem(OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    // ✅ Save all items of an order
    public List<OrderItem> saveAllOrderItems(List<OrderItem> items) {
        return orderItemRepository.saveAll(items);
    }

    // ✅ Fetch all order items
    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    // ✅ Fetch items by Order ID
    public List<OrderItem> getItemsByOrderId(Long orderId) {
        return orderItemRepository.findByOrder_OrderId(orderId);
    }

    // ✅ Fetch one item by ID
    public Optional<OrderItem> getOrderItemById(Long id) {
        return orderItemRepository.findById(id);
    }

    // ✅ Delete one item by ID
    public void deleteOrderItem(Long id) {
        orderItemRepository.deleteById(id);
    }

    // ✅ Delete all items for an order
    public void deleteItemsByOrderId(Long orderId) {
        List<OrderItem> items = orderItemRepository.findByOrder_OrderId(orderId);
        orderItemRepository.deleteAll(items);
    }
}
