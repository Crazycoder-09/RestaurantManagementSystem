package com.app.Restaurant_Management.controller;


import com.app.Restaurant_Management.entity.Inventory;
import com.app.Restaurant_Management.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(origins = "http://localhost:3002")

public class InventoryController {

    @Autowired
    private  InventoryService inventoryService;

    // ➕ Add / Update
    @PostMapping
    public ResponseEntity<Inventory> saveInventory(@RequestBody Inventory inventory) {
        return ResponseEntity.ok(inventoryService.saveInventory(inventory));
    }

    // 📄 Get all
    @GetMapping
    public ResponseEntity<List<Inventory>> getAllInventory() {
        return ResponseEntity.ok(inventoryService.getAllInventory());
    }

    // 🔍 Get by ID
    @GetMapping("/{id}")
    public ResponseEntity<Inventory> getInventoryById(@PathVariable Long id) {
        return ResponseEntity.ok(inventoryService.getInventoryById(id));
    }

    // 🔄 Update stock
    @PutMapping("/{id}/stock")
    public ResponseEntity<Inventory> updateStock(
            @PathVariable Long id,
            @RequestParam Double newStock) {
        return ResponseEntity.ok(inventoryService.updateStock(id, newStock));
    }

    // ❌ Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteInventory(@PathVariable Long id) {
        inventoryService.deleteInventory(id);
        return ResponseEntity.ok("Inventory deleted successfully.");
    }
}
