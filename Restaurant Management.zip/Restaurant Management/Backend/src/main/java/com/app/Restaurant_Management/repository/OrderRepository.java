package com.app.Restaurant_Management.repository;

import com.app.Restaurant_Management.entity.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Orders, Long> {}
