package com.app.Restaurant_Management.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "recipe_ingredient")
public class RecipeIngredient {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recipe_ingredient_id")
    private Long recipeIngredientId;

    @ManyToOne @JoinColumn(name = "item_id")
    private MenuItem item;

    @ManyToOne @JoinColumn(name = "ingredient_id")
    private Inventory ingredient;

    private Double quantityNeeded;

    public RecipeIngredient() {
    }

    public RecipeIngredient(Long recipeIngredientId, MenuItem item, Inventory ingredient, Double quantityNeeded) {
        this.recipeIngredientId = recipeIngredientId;
        this.item = item;
        this.ingredient = ingredient;
        this.quantityNeeded = quantityNeeded;
    }

    public Long getRecipeIngredientId() {
        return recipeIngredientId;
    }

    public void setRecipeIngredientId(Long recipeIngredientId) {
        this.recipeIngredientId = recipeIngredientId;
    }

    public MenuItem getItem() {
        return item;
    }

    public void setItem(MenuItem item) {
        this.item = item;
    }

    public Inventory getIngredient() {
        return ingredient;
    }

    public void setIngredient(Inventory ingredient) {
        this.ingredient = ingredient;
    }

    public Double getQuantityNeeded() {
        return quantityNeeded;
    }

    public void setQuantityNeeded(Double quantityNeeded) {
        this.quantityNeeded = quantityNeeded;
    }

    @Override
    public String toString() {
        return "RecipeIngredient{" +
                "recipeIngredientId=" + recipeIngredientId +
                ", item=" + item +
                ", ingredient=" + ingredient +
                ", quantityNeeded=" + quantityNeeded +
                '}';
    }
}
