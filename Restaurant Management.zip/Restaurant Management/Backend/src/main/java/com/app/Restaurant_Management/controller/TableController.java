package com.app.Restaurant_Management.controller;


import com.app.Restaurant_Management.entity.RestaurantTable;
import com.app.Restaurant_Management.service.TableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tables")
@CrossOrigin(origins = "http://localhost:3002")

public class TableController {

    @Autowired
    private TableService tableService;

    // ➕ Add or Update Table
    @PostMapping
    public ResponseEntity<RestaurantTable> saveTable(@RequestBody RestaurantTable table) {
        return ResponseEntity.ok(tableService.saveTable(table));
    }

    // 📄 Get all tables
    @GetMapping
    public ResponseEntity<List<RestaurantTable>> getAllTables() {
        return ResponseEntity.ok(tableService.getAllTables());
    }

    // 🔍 Get by ID
    @GetMapping("/{id}")
    public ResponseEntity<RestaurantTable> getTableById(@PathVariable Long id) {
        return ResponseEntity.ok(tableService.getTableById(id));
    }

    // 🔄 Update table status
    @PutMapping("/{id}/status")
    public ResponseEntity<RestaurantTable> updateTableStatus(
            @PathVariable Long id,
            @RequestParam RestaurantTable.TableStatus status) {
        return ResponseEntity.ok(tableService.updateTableStatus(id, status));
    }

    // 🔄 Mark occupied/free
    @PutMapping("/{id}/occupied")
    public ResponseEntity<RestaurantTable> setOccupied(
            @PathVariable Long id,
            @RequestParam boolean occupied) {
        return ResponseEntity.ok(tableService.setOccupied(id, occupied));
    }

    // ❌ Delete Table
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTable(@PathVariable Long id) {
        tableService.deleteTable(id);
        return ResponseEntity.ok("Table deleted successfully.");
    }
}

