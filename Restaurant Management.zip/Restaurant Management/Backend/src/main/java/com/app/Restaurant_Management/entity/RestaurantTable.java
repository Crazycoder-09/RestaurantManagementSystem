package com.app.Restaurant_Management.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "restaurant_table")
public class RestaurantTable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "table_id")
    private Long tableId;

    private Integer capacity;
    private String location;
    private Boolean isOccupied = false;

    @Enumerated(EnumType.STRING)
    private TableStatus status = TableStatus.Available;

    public enum TableStatus {
        Available, Waiting_for_order, SERVING, NEEDS_CLEANING
    }

    public RestaurantTable() {
    }

    public RestaurantTable(Long tableId, Integer capacity, String location, Boolean isOccupied, TableStatus status) {
        this.tableId = tableId;
        this.capacity = capacity;
        this.location = location;
        this.isOccupied = isOccupied;
        this.status = status;
    }

    public Long getTableId() {
        return tableId;
    }

    public void setTableId(Long tableId) {
        this.tableId = tableId;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Boolean getOccupied() {
        return isOccupied;
    }

    public void setOccupied(Boolean occupied) {
        isOccupied = occupied;
    }

    public TableStatus getStatus() {
        return status;
    }

    public void setStatus(TableStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RestaurantTable{" +
                "tableId=" + tableId +
                ", capacity=" + capacity +
                ", location='" + location + '\'' +
                ", isOccupied=" + isOccupied +
                ", status=" + status +
                '}';
    }
}
