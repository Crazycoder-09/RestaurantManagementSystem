package com.app.Restaurant_Management.controller;

import com.app.Restaurant_Management.entity.OrderItem;
import com.app.Restaurant_Management.entity.Orders;
import com.app.Restaurant_Management.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/orders")
@CrossOrigin(origins = "http://localhost:3000")

public class OrderController {

    @Autowired
    private OrderRepository ordersRepository;

    // ✅ Create new order
    @PostMapping
    public Orders createOrder(@RequestBody Orders order) {
        System.out.println("🟢 Received order from frontend: " + order);

        // 🧠 Link each OrderItem to its parent order
        if (order.getItems() != null) {
            for (OrderItem item : order.getItems()) {
                item.setOrder(order);
            }
        }

        Orders saved = ordersRepository.save(order);
        System.out.println("✅ Saved Order: " + saved.getOrderId());
        return saved;
    }

    // ✅ Get all orders
    @GetMapping
    public List<Orders> getAllOrders() {
        return ordersRepository.findAll();
    }
}
