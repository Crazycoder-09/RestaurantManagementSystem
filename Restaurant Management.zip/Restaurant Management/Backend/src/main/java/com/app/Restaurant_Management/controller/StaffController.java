package com.app.Restaurant_Management.controller;


import com.app.Restaurant_Management.entity.Staff;
import com.app.Restaurant_Management.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/staff")
@CrossOrigin(origins = "http://localhost:3002")

public class StaffController {
@Autowired
    private  final StaffService staffService;

    public StaffController(StaffService staffService) {
        this.staffService = staffService;
    }


    // ➕ Create or Update Staff
    @PostMapping
    public ResponseEntity<Staff> saveStaff(@RequestBody Staff staff) {
        return ResponseEntity.ok(staffService.saveStaff(staff));
    }

    // 📄 Get all staff
    @GetMapping
    public ResponseEntity<List<Staff>> getAllStaff() {
        return ResponseEntity.ok(staffService.getAllStaff());
    }

    // 🔍 Get by ID
    @GetMapping("/{id}")
    public ResponseEntity<Staff> getStaffById(@PathVariable Long id) {
        return ResponseEntity.ok(staffService.getStaffById(id));
    }

    // ❌ Delete Staff
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStaff(@PathVariable Long id) {
        staffService.deleteStaff(id);
        return ResponseEntity.ok("Staff deleted successfully.");
    }
}
