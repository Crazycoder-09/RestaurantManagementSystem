package com.app.Restaurant_Management.controller;


import com.app.Restaurant_Management.entity.TransactionRecord;
import com.app.Restaurant_Management.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@CrossOrigin(origins = "http://localhost:3002")

public class TransactionController {

    @Autowired
    private  TransactionService transactionService;

    // ➕ Create transaction
    @PostMapping
    public ResponseEntity<TransactionRecord> saveTransaction(@RequestBody TransactionRecord transaction) {
        return ResponseEntity.ok(transactionService.saveTransaction(transaction));
    }

    // 📄 Get all
    @GetMapping
    public ResponseEntity<List<TransactionRecord>> getAllTransactions() {
        return ResponseEntity.ok(transactionService.getAllTransactions());
    }

    // 🔍 Get by ID
    @GetMapping("/{id}")
    public ResponseEntity<TransactionRecord> getTransactionById(@PathVariable Long id) {
        return ResponseEntity.ok(transactionService.getTransactionById(id));
    }

    // ❌ Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTransaction(@PathVariable Long id) {
        transactionService.deleteTransaction(id);
        return ResponseEntity.ok("Transaction deleted successfully.");
    }
}

