package com.app.Restaurant_Management.controller;


import com.app.Restaurant_Management.entity.MenuItem;
import com.app.Restaurant_Management.service.MenuItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

@RestController
@RequestMapping("/api/menu-items")
@CrossOrigin(origins = "http://localhost:3000")

public class MenuItemController {

    @Autowired
    private MenuItemService menuItemService;

    // ➕ Add / Update Menu Item
    @PostMapping
    public ResponseEntity<MenuItem> saveMenuItem(@RequestBody MenuItem item) {
        return ResponseEntity.ok(menuItemService.saveMenuItem(item));
    }

    // 📄 Get all menu items
    @GetMapping
    public ResponseEntity<List<MenuItem>> getAllMenuItems() {
        return ResponseEntity.ok(menuItemService.getAllMenuItems());
    }

    // 🔍 Get by ID
    @GetMapping("/{id}")
    public ResponseEntity<MenuItem> getMenuItemById(@PathVariable Long id) {
        return ResponseEntity.ok(menuItemService.getMenuItemById(id));
    }

    // 🟢 Update availability
//    @PutMapping("/{id}/availability")
//    public ResponseEntity<MenuItem> updateAvailability(
//            @PathVariable Long id,
//            @RequestParam boolean is_available) {
//        return ResponseEntity.ok(menuItemService.updateAvailability(id, is_available));
//    }

    // 🟡 Update entire menu item
    @PutMapping("/{id}")
    public ResponseEntity<MenuItem> updateMenuItem(@PathVariable Long id, @RequestBody MenuItem updatedItem) {
        MenuItem existing = menuItemService.getMenuItemById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }

        existing.setName(updatedItem.getName());
        existing.setCategory(updatedItem.getCategory());
        existing.setPrice(updatedItem.getPrice());
        existing.setDescription(updatedItem.getDescription());
        existing.setAvailable(updatedItem.getAvailable());

        return ResponseEntity.ok(menuItemService.saveMenuItem(existing));
    }

    // ❌ Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteMenuItem(@PathVariable Long id) {
        menuItemService.deleteMenuItem(id);
        return ResponseEntity.ok("Menu item deleted successfully.");
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file) {
        try {
            // Folder to save images
            String uploadDir = "uploads/";
            Files.createDirectories(Paths.get(uploadDir));

            // Generate unique file name
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path path = Paths.get(uploadDir + fileName);

            // Save file locally
            Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

            // Return accessible URL (this assumes localhost:8080/images is mapped)
            String imageUrl = "http://localhost:8081/images/" + fileName;
//            MenuItem menuItem = null;
//            menuItem.setImageUrl(imageUrl);
//            menuItemService.saveMenuItem(menuItem);

            return ResponseEntity.ok(imageUrl);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Image upload failed: " + e.getMessage());
        }
    }

}
