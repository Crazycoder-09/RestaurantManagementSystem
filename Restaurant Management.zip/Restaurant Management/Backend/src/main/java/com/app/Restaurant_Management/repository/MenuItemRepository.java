package com.app.Restaurant_Management.repository;

import com.app.Restaurant_Management.entity.MenuItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {}

