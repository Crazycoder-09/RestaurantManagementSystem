package com.app.Restaurant_Management.service;



import com.app.Restaurant_Management.ecxeption.ResourceNotFoundException;
import com.app.Restaurant_Management.entity.RestaurantTable;
import com.app.Restaurant_Management.repository.TableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TableService {

    @Autowired
    private  TableRepository tableRepository;

    public RestaurantTable saveTable(RestaurantTable table) {
        return tableRepository.save(table);
    }

    public List<RestaurantTable> getAllTables() {
        return tableRepository.findAll();
    }

    public RestaurantTable getTableById(Long id) {
        return tableRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Table not found with id: " + id));
    }

    public void deleteTable(Long id) {
        if (!tableRepository.existsById(id)) {
            throw new ResourceNotFoundException("Table not found with id: " + id);
        }
        tableRepository.deleteById(id);
    }

    // Business Logic: Update Table Status
    public RestaurantTable updateTableStatus(Long id, RestaurantTable.TableStatus status) {
        RestaurantTable table = getTableById(id);
        table.setStatus(status);
        return tableRepository.save(table);
    }

    // Mark Occupied or Available
    public RestaurantTable setOccupied(Long id, boolean occupied) {
        RestaurantTable table = getTableById(id);
        table.setOccupied(occupied);
//        table.setIsOccupied(occupied);
        return tableRepository.save(table);
    }
}

