package com.app.Restaurant_Management.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "billing")
public class Billing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long billId;

    private String customerName;
    private String tableNo;
    private String orderNote;

    private Double subTotal;
    private Double gstPercent;
    private Double gstAmount;
    private Double grandTotal;

    private LocalDateTime billDate;

    // ✅ One-to-Many for order items
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "bill_id") // foreign key
    private List<BillingItem> items;

    // getters and setters

    public Billing() {
    }

    public Billing(Long billId, String customerName, String tableNo, String orderNote, Double subTotal, Double gstPercent, Double gstAmount, Double grandTotal, LocalDateTime billDate, List<BillingItem> items) {
        this.billId = billId;
        this.customerName = customerName;
        this.tableNo = tableNo;
        this.orderNote = orderNote;
        this.subTotal = subTotal;
        this.gstPercent = gstPercent;
        this.gstAmount = gstAmount;
        this.grandTotal = grandTotal;
        this.billDate = billDate;
        this.items = items;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTableNo() {
        return tableNo;
    }

    public void setTableNo(String tableNo) {
        this.tableNo = tableNo;
    }

    public String getOrderNote() {
        return orderNote;
    }

    public void setOrderNote(String orderNote) {
        this.orderNote = orderNote;
    }

    public Double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(Double subTotal) {
        this.subTotal = subTotal;
    }

    public Double getGstPercent() {
        return gstPercent;
    }

    public void setGstPercent(Double gstPercent) {
        this.gstPercent = gstPercent;
    }

    public Double getGstAmount() {
        return gstAmount;
    }

    public void setGstAmount(Double gstAmount) {
        this.gstAmount = gstAmount;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public LocalDateTime getBillDate() {
        return billDate;
    }

    public void setBillDate(LocalDateTime billDate) {
        this.billDate = billDate;
    }

    public List<BillingItem> getItems() {
        return items;
    }

    public void setItems(List<BillingItem> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "Billing{" +
                "billId=" + billId +
                ", customerName='" + customerName + '\'' +
                ", tableNo='" + tableNo + '\'' +
                ", orderNote='" + orderNote + '\'' +
                ", subTotal=" + subTotal +
                ", gstPercent=" + gstPercent +
                ", gstAmount=" + gstAmount +
                ", grandTotal=" + grandTotal +
                ", billDate=" + billDate +
                ", items=" + items +
                '}';
    }
}
