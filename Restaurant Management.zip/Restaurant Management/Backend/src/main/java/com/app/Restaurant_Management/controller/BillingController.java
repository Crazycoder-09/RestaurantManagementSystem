package com.app.Restaurant_Management.controller;

import com.app.Restaurant_Management.entity.Billing;
import com.app.Restaurant_Management.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/billing")
@CrossOrigin(origins = "http://localhost:3000")

public class BillingController {

    @Autowired
    private BillingService billingService;

    @PostMapping
    public ResponseEntity<Billing> saveBill(@RequestBody Billing bill) {
        Billing savedBill = billingService.saveBill(bill);
        return ResponseEntity.ok(savedBill);
    }
    @GetMapping
    public ResponseEntity<List<Billing>> getAllBills() {
        List<Billing> bills = billingService.getAllBills();
        return ResponseEntity.ok(bills);
    }

}
