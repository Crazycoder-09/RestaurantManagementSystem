package com.app.Restaurant_Management.service;

import com.app.Restaurant_Management.entity.Billing;
import com.app.Restaurant_Management.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillingService {

    @Autowired
    private BillingRepository billingRepository;

    public Billing saveBill(Billing bill) {
        return billingRepository.save(bill);
    }
    public List<Billing> getAllBills() {
        return billingRepository.findAll();
    }

}
