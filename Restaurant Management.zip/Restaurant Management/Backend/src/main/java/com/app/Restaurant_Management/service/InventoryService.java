package com.app.Restaurant_Management.service;


import com.app.Restaurant_Management.ecxeption.ResourceNotFoundException;
import com.app.Restaurant_Management.entity.Inventory;
import com.app.Restaurant_Management.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private  InventoryRepository inventoryRepository;

    public Inventory saveInventory(Inventory inventory) {
        return inventoryRepository.save(inventory);
    }

    public List<Inventory> getAllInventory() {
        return inventoryRepository.findAll();
    }

    public Inventory getInventoryById(Long id) {
        return inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory item not found with id: " + id));
    }

    public void deleteInventory(Long id) {
        if (!inventoryRepository.existsById(id)) {
            throw new ResourceNotFoundException("Inventory item not found with id: " + id);
        }
        inventoryRepository.deleteById(id);
    }

    // Update Stock
    public Inventory updateStock(Long id, Double newStock) {
        Inventory item = getInventoryById(id);
        item.setCurrentStock(newStock);
        return inventoryRepository.save(item);
    }

    // Reduce Stock (used when order is fulfilled)
    public void reduceStock(Long id, Double usedQty) {
        Inventory item = getInventoryById(id);
        double updated = item.getCurrentStock() - usedQty;
        item.setCurrentStock(Math.max(0, updated));
        inventoryRepository.save(item);
    }
}
