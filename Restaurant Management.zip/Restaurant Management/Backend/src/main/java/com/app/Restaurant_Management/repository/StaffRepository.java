package com.app.Restaurant_Management.repository;

import com.app.Restaurant_Management.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StaffRepository extends JpaRepository<Staff, Long> {}
