package com.app.Restaurant_Management.entity;


import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transaction_record")
public class TransactionRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transaction_id")
    private Long transactionId;

    @OneToOne @JoinColumn(name = "order_id")
    private Orders order;

    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod = PaymentMethod.Cash;

    private Double amountPaid;
    private Double tipAmount = 0.0;
    private LocalDateTime transactionDatetime = LocalDateTime.now();

    public enum PaymentMethod { Cash, Card, Online, UPI }

    public TransactionRecord() {
    }

    public TransactionRecord(Long transactionId, Orders order, PaymentMethod paymentMethod, Double amountPaid, Double tipAmount, LocalDateTime transactionDatetime) {
        this.transactionId = transactionId;
        this.order = order;
        this.paymentMethod = paymentMethod;
        this.amountPaid = amountPaid;
        this.tipAmount = tipAmount;
        this.transactionDatetime = transactionDatetime;
    }

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Orders getOrder() {
        return order;
    }

    public void setOrder(Orders order) {
        this.order = order;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(Double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public Double getTipAmount() {
        return tipAmount;
    }

    public void setTipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
    }

    public LocalDateTime getTransactionDatetime() {
        return transactionDatetime;
    }

    public void setTransactionDatetime(LocalDateTime transactionDatetime) {
        this.transactionDatetime = transactionDatetime;
    }

    @Override
    public String toString() {
        return "TransactionRecord{" +
                "transactionId=" + transactionId +
                ", order=" + order +
                ", paymentMethod=" + paymentMethod +
                ", amountPaid=" + amountPaid +
                ", tipAmount=" + tipAmount +
                ", transactionDatetime=" + transactionDatetime +
                '}';
    }
}
