package com.app.Restaurant_Management.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "inventory")
public class Inventory {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ingredient_id")
    private Long ingredientId;

    @Column(nullable = false)
    private String name;

    private Double currentStock = 0.0;
    private String unitOfMeasure;
    private Double minStockLevel = 0.0;

    public Inventory() {
    }

    public Inventory(Long ingredientId, String name, Double currentStock, String unitOfMeasure, Double minStockLevel) {
        this.ingredientId = ingredientId;
        this.name = name;
        this.currentStock = currentStock;
        this.unitOfMeasure = unitOfMeasure;
        this.minStockLevel = minStockLevel;
    }

    public Long getIngredientId() {
        return ingredientId;
    }

    public void setIngredientId(Long ingredientId) {
        this.ingredientId = ingredientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getCurrentStock() {
        return currentStock;
    }

    public void setCurrentStock(Double currentStock) {
        this.currentStock = currentStock;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public Double getMinStockLevel() {
        return minStockLevel;
    }

    public void setMinStockLevel(Double minStockLevel) {
        this.minStockLevel = minStockLevel;
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "ingredientId=" + ingredientId +
                ", name='" + name + '\'' +
                ", currentStock=" + currentStock +
                ", unitOfMeasure='" + unitOfMeasure + '\'' +
                ", minStockLevel=" + minStockLevel +
                '}';
    }
}
