package com.app.Restaurant_Management.service;


import com.app.Restaurant_Management.ecxeption.ResourceNotFoundException;
import com.app.Restaurant_Management.entity.MenuItem;
import com.app.Restaurant_Management.repository.MenuItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuItemService {

    @Autowired
    private MenuItemRepository menuItemRepository;

    public MenuItem saveMenuItem(MenuItem item) {
        return menuItemRepository.save(item);
    }

    public List<MenuItem> getAllMenuItems() {
        return menuItemRepository.findAll();
    }

    public MenuItem getMenuItemById(Long id) {
        return menuItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Menu item not found with id: " + id));
    }

    public void deleteMenuItem(Long id) {
        if (!menuItemRepository.existsById(id)) {
            throw new ResourceNotFoundException("Menu item not found with id: " + id);
        }
        menuItemRepository.deleteById(id);
    }

    // Update Availability
    public MenuItem updateAvailability(Long id, boolean isAvailable) {
        MenuItem item = getMenuItemById(id);
        item.setAvailable(isAvailable);
//        item.setisAvailable(isAvailable);
        return menuItemRepository.save(item);
    }
}

