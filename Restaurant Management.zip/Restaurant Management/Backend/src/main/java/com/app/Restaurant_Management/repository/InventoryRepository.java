package com.app.Restaurant_Management.repository;

import com.app.Restaurant_Management.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {}
