import React from "react";
import { Navigate } from "react-router-dom";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import StaffList from "./components/StaffList";
import TableList from "./components/TableList";
import MenuList from "./components/MenuList";
import InventoryList from "./components/InventoryList";
import OrderList from "./components/OrderList";
import TransactionList from "./components/TransactionList";
import Cart from "./components/Cart";
import { CartProvider } from "./context/CartContext";
// import Orders from "./components/Orders";
import NewOrder from "./components/NewOrder"; // ✅ Import NewOrder
import Order from "./components/Order"; // ✅ Import new page
import Billing from "./components/Billing";
import Home from "./components/Home";
import AdminBilling from "./components/AdminBilling";
import AdminMenu from "./components/AdminMenu";
import Login from "./components/Login";
import ProtectedRoute from "./ProtectedRoute";
import { AuthProvider } from "./context/AuthContext";
import AdminOrders from "./components/AdminOrders";

export default function App() {

  return (
    <AuthProvider>
    <CartProvider>
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />

        <Route path="/staff" element={<StaffList />} />
        <Route path="/tables" element={<TableList />} />
        <Route path="/menu" element={<MenuList />} />
        <Route path="/inventory" element={<InventoryList />} />
        <Route path="/orders" element={<OrderList />} />
        <Route path="/transactions" element={<TransactionList />} />
        <Route path="/cart" element={<Cart/>}/>
                {/* <Route path="/orders" element={<Orders />} /> */}
            <Route path="/new-order" element={<NewOrder />} /> {/* ✅ New route */}
          <Route path="/order" element={<Order />} /> {/* ✅ New Route */}
<Route path="/billing" element={<Billing />} />
        <Route path="/admin/bills" element={<AdminBilling />} /> {/* ✅ */}
{/* <Route path="/admin/menu" element={<AdminMenu />} /> */}
        <Route path="/login" element={<Login />} />
<Route path="/admin/menu" element={<ProtectedRoute> <AdminMenu /></ProtectedRoute> }/>
  <Route path="/admin/orders" element={<AdminOrders />} />


        {/* <Route path="/" element={<div className="text-center mt-5"><h2>🍴 Welcome to Hotel Management System</h2></div>} /> */}
      </Routes>
      
    </Router>
    </CartProvider>
    </AuthProvider>
    
  );
}
