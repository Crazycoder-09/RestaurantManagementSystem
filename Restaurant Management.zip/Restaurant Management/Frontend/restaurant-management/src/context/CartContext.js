import React, { createContext, useContext, useState } from "react";

// ✅ Create context
const CartContext = createContext();

// ✅ Provider component
export const CartProvider = ({ children }) => {
  // Store the ordered items globally
  const [orders, setOrders] = useState([]);

  /**
   * ✅ Add a new menu item to the order list
   * If item already exists → update quantity instead of duplicating
   */
  const addToOrders = (newItem) => {
    setOrders((prevOrders) => {
      const existingItem = prevOrders.find(
        (item) => item.itemId === newItem.itemId
      );

      if (existingItem) {
        // Increment existing quantity
        return prevOrders.map((item) =>
          item.itemId === newItem.itemId
            ? { ...item, quantity: item.quantity + newItem.quantity }
            : item
        );
      } else {
        // Add new item
        return [...prevOrders, newItem];
      }
    });
  };

  /**
   * ✅ Remove a single item (for ❌ Cancel Item button)
   */
  const removeOrderItem = (itemId) => {
    setOrders((prevOrders) =>
      prevOrders.filter((item) => item.itemId !== itemId)
    );
  };

  /**
   * ✅ Clear all orders (🗑️ Clear Orders button)
   */
  const clearOrders = () => {
    if (window.confirm("Are you sure you want to clear all orders?")) {
      setOrders([]);
      localStorage.removeItem("activeOrder"); // optional cleanup
    }
  };

  return (
    <CartContext.Provider
      value={{
        orders,
        addToOrders,
        removeOrderItem,
        clearOrders,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

// ✅ Custom hook for easy use
export const useCart = () => useContext(CartContext);
