import React from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div
      className="home-container"
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/images/restaurant-bg.jpg)`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="home-overlay">
        <div className="home-content">
          <h1 className="home-title">🍴 Welcome to Hotel Royal Spice</h1>
          <p className="home-subtitle">
            Experience the taste of authentic flavors served with warmth and care.
          </p>

          <div className="home-buttons">
            <button className="btn-order" onClick={() => navigate("/new-order")}>
              🆕 Start New Order
            </button>
            <button className="btn-menu" onClick={() => navigate("/menu")}>
              📜 View Menu
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
