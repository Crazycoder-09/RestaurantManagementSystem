import React, { useState, useEffect } from "react";
import axios from "../api/axiosConfig";
import "./MenuList.css";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";

export default function MenuList() {
  const [menu, setMenu] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [filter, setFilter] = useState("All");
  const { addToOrders } = useCart();
  const navigate = useNavigate();
// ✅ Scroll-to-Top button visibility
const [showScroll, setShowScroll] = useState(false);

useEffect(() => {
  const handleScroll = () => {
    setShowScroll(window.scrollY > 300);
  };
  window.addEventListener("scroll", handleScroll);
  return () => window.removeEventListener("scroll", handleScroll);
}, []);

// ✅ Scroll smoothly to top
const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
};

  // ✅ Fetch menu items
  useEffect(() => {
    const fetchMenu = async () => {
      try {
        const res = await axios.get("/menu-items");
        const menuWithQty = res.data.map((item) => ({ ...item, quantity: 1 }));
        setMenu(menuWithQty);
      } catch (error) {
        console.error("Error fetching menu:", error);
      }
    };
    fetchMenu();
  }, []);

  // ✅ Function to map item name to image file
  const getImageForItem = (name) => {
    const key = name.trim().toLowerCase();
    const map = {
      "paneer butter masala": "/images/paneer.jpg",
      "veg thali": "/images/veg thali.jpg",
      "veg burger": "/images/Burger.jpg",
      "veg sandwich": "/images/sandwich.jpg",
      "kaju paneer" : "/images/KajuPaneer.jpg",
      "bengan masala":"/images/BenganMasala.jpg",
      "masala dosa":"/images/Masala Dosa.jpg",
      "biryani":"/images/Biryani.jpg",
      "palak paneer":"/images/Palak Paneer.jpg",
      "butter chicken":"/images/Butter Chicken.jpg",
      "dal makhani":"/images/Dal Makhani.jpg",
      "shahi paneer":"/images/Shahi Paneer.jpg",
    };
    return process.env.PUBLIC_URL + (map[key] || "/images/default.jpg");
  };

  // ✅ Filter menu by category
  const filteredMenu =
    filter === "All"
      ? menu
      : menu.filter((item) => item.category === filter.toUpperCase());



  // ✅ Quantity controls
 const increaseQuantity = (itemId) => {
  setMenu((prev) =>
    prev.map((item) =>
      item.itemId === itemId
        ? { ...item, quantity: (item.quantity || 1) + 1 }
        : item
    )
  );
};

const decreaseQuantity = (itemId) => {
  setMenu((prev) =>
    prev.map((item) =>
      item.itemId === itemId && item.quantity > 1
        ? { ...item, quantity: item.quantity - 1 }
        : item
    )
  );
};

  // ✅ Select/Unselect items
  const toggleSelectItem = (item) => {
    setSelectedItems((prev) =>
      prev.some((i) => i.itemId === item.itemId)
        ? prev.filter((i) => i.itemId !== item.itemId)
        : [...prev, item]
    );
  };

  // ✅ Add selected items to order
  const addAllToOrder = () => {
    if (selectedItems.length === 0) {
      alert("Please select at least one menu item!");
      return;
    }

    selectedItems.forEach((item) => {
      const imageUrl = getImageForItem(item.name);
      addToOrders({ ...item, imageUrl });
    });

    alert(`${selectedItems.length} item(s) added to Orders ✅`);
    setSelectedItems([]);
  };

  // ✅ Navigate to next page
  const handleNext = () => {
    navigate("/order");
  };
  

  return (
    
    <div
      className="menu-page-container"
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/images/Menubackground.jpg)`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
    {/* 🟡 Scroll to Top Floating Button */}
{showScroll && (
  <button
    className="scroll-top-btn"
    onClick={scrollToTop}
    title="Back to top"
  >
    ↑
  </button>
)}

      <div className="menu-overlay">
        <div className="container mt-4">
          {/* 🍛 CATEGORY FILTER BAR */}
          {/* <div className="category-bar sticky-top bg-light py-2 mb-3 shadow-sm rounded-pill d-flex justify-content-center gap-3 flex-wrap">
            {[
              { label: "🥗 Appetizer", value: "Appetizer" },
              { label: "🍕 Main Course", value: "Main Course" },
              { label: "🍨 Dessert", value: "Dessert" },
              { label: "🥤 Drinks", value: "Drinks" },
            ].map((cat) => (
              <button
                key={cat.value}
                className={`btn btn-sm ${
                  filter === cat.value
                    ? "btn-primary"
                    : "btn-outline-primary bg-white"
                } rounded-pill px-3 fw-semibold`}
                onClick={() => setFilter(cat.value)}
              >
                {cat.label}
              </button>
            ))}
          </div> */}

          <h2 className="menu-title text-center mb-4">
            🍴 Explore Our Delicious Menu
          </h2>

          {/* 🍔 Menu Grid */}
          <div className="menu-grid">
            {filteredMenu.map((item) => (
              <div className="menu-card" key={item.itemId}>
                <img
                  src={getImageForItem(item.name)}
                  alt={item.name}
                  className="menu-image"
                />

                <h5 className="menu-item-name">{item.name}</h5>
                <p>Description:{item.description}</p>
                <p>Category: {item.category}</p>
                <p>Unit Price: ₹{item.price}</p>


              <p>
  {item.isAvailable ? (
    <span className="text-success fw-bold">❌ Not Available</span>
  ) : (
    <span className="text-danger fw-bold">✅ Available</span>
  )}
</p>



                {item.isAvailable || (
    <>
      <div className="quantity-control">
        <button
          className="btn btn-sm btn-outline-secondary"
          onClick={() => decreaseQuantity(item.itemId)}
          disabled={item.quantity <= 1}
        >
          ➖
        </button>
        <span className="qty-display">{item.quantity ?? 1}</span>
        <button
          className="btn btn-sm btn-outline-secondary"
          onClick={() => increaseQuantity(item.itemId)}
        >
          ➕
        </button>
      </div>

      <p className="item-total">
        Total Price: ₹
        {((item.price || 0) * (item.quantity || 1)).toFixed(2)}
      </p>
    </>
  )}



                {/* 🟩 Select Button */}
                 <button
    className={`btn ${
      selectedItems.some((i) => i.itemId === item.itemId)
        ? "btn-success"
        : "btn-outline-primary"
    } mt-2`}
    onClick={() => toggleSelectItem(item)}
    disabled={item.isAvailable}
  >
    {selectedItems.some((i) => i.itemId === item.itemId)
      ? "✅ Selected"
      : "Select"}
  </button>
</div>
            ))}
          </div>

          {/* ✅ Floating Buttons */}
          <div className="floating-buttons">
            <button
              className="btn btn-primary btn-lg add-btn"
              onClick={addAllToOrder}
            >
              🛒 Add {selectedItems.length > 0 ? selectedItems.length : ""} Item(s)
            </button>

            <button
              className="btn btn-warning btn-lg next-btn"
              onClick={handleNext}
            >
              Next ➡️
            </button>
           {/* <button
    className="scroll-top-btn"
    onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
  >
    ⬆️ Top
  </button> */}

          </div>
        </div>
      </div>
    </div>
  );
}
