import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./NewOrder.css";

export default function NewOrder() {
  const [customerName, setCustomerName] = useState("");
  const [tableNo, setTableNo] = useState("");
  const [orderNote, setOrderNote] = useState("");
  const [orderPlaced, setOrderPlaced] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    const newOrder = {
      customerName,
      tableNo,
      orderNote,
      createdAt: new Date().toISOString(),
    };

    console.log("🆕 New Order Created:", newOrder);

    localStorage.setItem("activeOrder", JSON.stringify(newOrder));

    setOrderPlaced(true);

    setTimeout(() => {
      navigate("/menu");
    }, 800);
  };

  return (
    <div
     className="home-container"
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/images/background.jpg)`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="new-order-overlay">
        <div className="new-order-container">
          <h2>🆕 Create New Order</h2>
          <p>Fill in details to start a new customer order.</p>

          <form onSubmit={handleSubmit} className="order-form">
            <div className="form-group">
              <label>👤 Customer Name:</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label>🍽️ Table Number:</label>
              <input
                type="number"
                value={tableNo}
                onChange={(e) => setTableNo(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label>📝 Special Notes:</label>
              <textarea
                rows="3"
                value={orderNote}
                onChange={(e) => setOrderNote(e.target.value)}
                placeholder="Add any special requests..."
              ></textarea>
            </div>

            <button type="submit" className="btn-create">
              ✅ Create Order
            </button>
          </form>

          {orderPlaced && (
            <div className="success-message">
              🎉 Order created successfully! Redirecting to Menu...
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
