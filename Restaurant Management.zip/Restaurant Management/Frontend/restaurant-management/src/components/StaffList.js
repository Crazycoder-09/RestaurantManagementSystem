import React, { useEffect, useState } from "react";
import axios from "../api/axiosConfig";
import './StaffList.css';
export default function StaffList() {
  const [staff, setStaff] = useState([]);

  const fetchStaff = async () => {
    const res = await axios.get("/staff");
    setStaff(res.data);
  };

  return (
    <div className="container mt-4">
      <h3>👨‍🍳 Staff List</h3>
      <button className="btn btn-primary mb-3" onClick={fetchStaff}>
        Load Staff
      </button>
      <center>
      <table className="table table-striped table-bordered">
        <thead className="table-dark">
          <tr>
            <th>ID</th><th>Name</th><th>Role</th><th>Contact</th>
          </tr>
        </thead>
        <tbody>
          {staff.map(s => (
            <tr key={s.staffId}>
              <td>{s.staffId}</td>
              <td>{s.firstName} {s.lastName}</td>
              <td>{s.role}</td>
              <td>{s.contactNumber}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </center>
    </div>
  );
}
