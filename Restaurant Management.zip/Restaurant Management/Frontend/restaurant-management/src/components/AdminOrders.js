import React, { useEffect, useState } from "react";
import axios from "../api/axiosConfig";
import "./AdminOrders.css";

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);

  // ✅ Fetch orders from backend
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await axios.get("/orders");
        // Sort newest first
        const sorted = res.data.sort((a, b) => b.orderId - a.orderId);
        setOrders(sorted);
      } catch (error) {
        console.error("❌ Error fetching orders:", error);
      }
    };
    fetchOrders();
  }, []);

  return (
    <div className="admin-orders-container">
      <h2>📜 All Orders</h2>

      {/* ✅ No Orders */}
      {orders.length === 0 ? (
        <p className="no-orders-msg">No orders found yet.</p>
      ) : (
        <table className="admin-orders-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Table</th>
              <th>Total</th>
              <th>Items</th>
              <th>Date / Time</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.orderId}>
                <td>{order.orderId}</td>
                <td>{order.customerName || "—"}</td>
                <td>{order.tableNo || "—"}</td>
                <td>₹{order.totalAmount?.toFixed(2) || "0.00"}</td>

                {/* ✅ Safe mapping of items */}
                <td>
                  {order.items && Array.isArray(order.items) && order.items.length > 0 ? (
                    order.items.map((item) => (
                      <div key={item.orderItemId || `${item.name}-${Math.random()}`}>
                        {item.name} × {item.quantity}
                      </div>
                    ))
                  ) : (
                    <span style={{ color: "#888" }}>No items</span>
                  )}
                </td>

                {/* ✅ Optional Date/Time */}
                <td>
                  {order.createdAt
                    ? new Date(order.createdAt).toLocaleString("en-IN", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })
                    : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
