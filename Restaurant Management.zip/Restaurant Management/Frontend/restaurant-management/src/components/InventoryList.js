import React, { useState } from "react";
import axios from "../api/axiosConfig";
import './InventoryList.css';
export default function InventoryList() {
  const [items, setItems] = useState([]);

  const fetchInventory = async () => {
    const res = await axios.get("/inventory");
    setItems(res.data);
  };

  return (
    <div className="container mt-4">
      <h3>📦 Inventory</h3>
      <button className="btn btn-warning mb-3" onClick={fetchInventory}>Load Inventory</button>
      <center>
      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th><th>Name</th><th>Stock</th><th>Unit</th>
          </tr>
        </thead>
        <tbody>
          {items.map(i => (
            <tr key={i.ingredientId}>
              <td>{i.ingredientId}</td>
              <td>{i.name}</td>
              <td>{i.currentStock}</td>
              <td>{i.unitOfMeasure}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </center>
    </div>
  );
}
