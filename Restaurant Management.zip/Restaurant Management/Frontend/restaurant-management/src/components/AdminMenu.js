import React, { useEffect, useState } from "react";
import axios from "../api/axiosConfig";
import "./AdminMenu.css";

export default function AdminMenu() {
  const [menu, setMenu] = useState([]);
  const [form, setForm] = useState({
    name: "",
    category: "",
    price: "",
    description: "",
    isAvailable: true,
  });
  const [editId, setEditId] = useState(null);

  // ✅ Fetch all menu items
  const fetchMenu = async () => {
    try {
      const res = await axios.get("/menu-items");
      setMenu(res.data);
    } catch (error) {
      console.error("❌ Error fetching menu:", error);
    }
  };

  useEffect(() => {
    fetchMenu();
  }, []);

  // ✅ Add or Update Item
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await axios.put(`/menu-items/${editId}`, form);
        alert("✅ Menu Item Updated Successfully!");
      } else {
        await axios.post("/menu-items", form);
        alert("✅ New Menu Item Added!");
      }
      setForm({
        name: "",
        category: "",
        price: "",
        description: "",
        isAvailable: true,
      });
      setEditId(null);
      fetchMenu();
    } catch (error) {
      console.error("❌ Error saving item:", error);
      alert("⚠️ Failed to save menu item!");
    }
  };

  // ✅ Edit existing item
  const handleEdit = (item) => {
    setEditId(item.itemId);
    setForm(item);
  };

  // ✅ Delete item
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      try {
        await axios.delete(`/menu-items/${id}`);
        alert("🗑️ Item Deleted Successfully!");
        fetchMenu();
      } catch (error) {
        console.error("❌ Error deleting item:", error);
        alert("⚠️ Failed to delete item!");
      }
    }
  };

  return (
    <div className="admin-menu-container">
      <h2>🍽️ Manage Menu Items</h2>


      {/* 🧾 Menu Form */}
      <form onSubmit={handleSubmit} className="menu-form">
        <input
          type="text"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Category"
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="Price"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          required
        />
        <textarea
          placeholder="Description"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        ></textarea>

        <label>
          <input
            type="checkbox"
            checked={form.isAvailable}
            onChange={(e) =>
              setForm({ ...form, isAvailable: e.target.checked })
            }
          />{" "}
          Available
        </label>

        <button type="submit" className="btn-save">
          {editId ? "💾 Update Item" : "➕ Add Item"}
        </button>
      </form>

      {/* 🍴 Menu Table */}
      <table className="menu-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Description</th>
            <th>Price</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {menu.map((item) => (
            <tr key={item.itemId}>
              <td>{item.itemId}</td>
              <td>{item.name}</td>
              <td>{item.category}</td>
              <td title={item.description || "No description"}>
                {item.description || "-"}
              </td>
              <td>₹{item.price}</td>
              <td>{item.isAvailable ? "❌" :"✅" }</td>
              <td>
                <button className="btn-edit" onClick={() => handleEdit(item)}>
                  ✏️
                </button>
                <button
                  className="btn-delete"
                  onClick={() => handleDelete(item.itemId)}
                >
                  🗑️
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
