import React, { useEffect, useState } from "react";
import axios from "../api/axiosConfig";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import "./Order.css";

export default function Order() {
  const { orders, clearOrders, removeOrderItem } = useCart();
  const [activeOrder, setActiveOrder] = useState(null);
  const navigate = useNavigate();

  // ✅ Load active order details
  useEffect(() => {
    const stored = localStorage.getItem("activeOrder");
    if (stored) {
      setActiveOrder(JSON.parse(stored));
    }
  }, []);

  // ✅ Calculate total amount
  const totalAmount = orders.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // ✅ Navigate back to menu
  const handleBackToMenu = () => {
    navigate("/menu");
  };

  // ✅ Proceed to billing
  const handleBillingRedirect = () => {
    if (orders.length === 0) {
      alert("Please add at least one item before generating the bill!");
      return;
    }
    navigate("/billing");
  };

  // ✅ Cancel a specific menu item
  const handleCancelItem = (itemId) => {
    if (window.confirm("Are you sure you want to remove this item?")) {
      removeOrderItem(itemId);
    }
  };

  // ✅ DONE → Save order in DB & redirect to Admin Orders page
  const handleDone = async () => {
    if (!activeOrder || orders.length === 0) {
      alert("⚠️ Cannot complete order. Missing data!");
      return;
    }

    const payload = {
      customerName: activeOrder.customerName,
      tableNo: activeOrder.tableNo,
      orderNote: activeOrder.orderNote,
      totalAmount,
      items: orders.map((item) => ({
        name: item.name,
        quantity: item.quantity,
        price: item.price,
      })),
    };

      console.log("🚀 Sending order payload:", payload); // ✅ debug line

    try {
      await axios.post("/orders", payload);
      alert("✅ Order saved successfully!");
      clearOrders();
      localStorage.removeItem("activeOrder");
      navigate("/admin/orders"); // redirect to admin orders tab
      
    } catch (error) {
      console.error("❌ Error saving order:", error);
      alert("Failed to save order. Please try again.");
    }
  };

  return (
    <div
      className="container mt-4"
      style={{
        backgroundImage: "url('/images/OrderBackground.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "100vh",
      }}
    >
      <h3>🧾 Order Summary</h3>

      {/* ✅ Customer Info */}
      {activeOrder ? (
        <div className="active-order-box">
          <p><strong>👤 Customer:</strong> {activeOrder.customerName}</p>
          <p><strong>🍽️ Table No:</strong> {activeOrder.tableNo}</p>
          {activeOrder.orderNote && (
            <p><strong>📝 Note:</strong> {activeOrder.orderNote}</p>
          )}
        </div>
      ) : (
        <p className="no-order-warning">
          ⚠️ No active order found. Please create a new one.
        </p>
      )}

      {/* ✅ Ordered Items */}
      {orders.length === 0 ? (
        <p>No items ordered yet!</p>
      ) : (
        <>
          <div className="order-list">
            {orders.map((item) => (
              <div key={item.itemId} className="order-card">
                <img
                  src={item.imageUrl}
                  alt={item.name}
                  className="order-image"
                />
                <div className="order-details">
                  <h5>{item.name}</h5>
                  <p>Qty: {item.quantity}</p>
                  <p>Price: ₹{item.price}</p>
                  <p>Total: ₹{item.price * item.quantity}</p>
                </div>

                <button
                  className="btn btn-cancel"
                  onClick={() => handleCancelItem(item.itemId)}
                >
                  ❌ Cancel
                </button>
              </div>
            ))}
          </div>

          <h4 className="mt-3">Grand Total: ₹{totalAmount}</h4>

          <div className="order-buttons">
            <button className="btn btn-secondary" onClick={handleBackToMenu}>
              ⬅️ Back to Menu
            </button>

            <button className="btn btn-danger" onClick={clearOrders}>
              🗑️ Clear Orders
            </button>

            <button className="btn btn-success ms-3" onClick={handleBillingRedirect}>
              💳 Proceed to Billing
            </button>

            {/* ✅ Done Button */}
            <button className="btn btn-primary ms-3" onClick={handleDone}>
              ✅ Done
            </button>
          </div>
        </>
      )}
    </div>
  );
}
