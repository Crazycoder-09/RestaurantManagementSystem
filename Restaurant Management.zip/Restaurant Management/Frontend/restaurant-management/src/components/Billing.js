import React, { useEffect, useState } from "react";
import { useCart } from "../context/CartContext";
import "./Billing.css";
import axios from "../api/axiosConfig";

export default function Billing() {
  const { orders, clearOrders } = useCart();
  const [activeOrder, setActiveOrder] = useState(null);
  const [gstPercent] = useState(5); // Example: 5% GST
  const [currentDateTime, setCurrentDateTime] = useState("");

  // ✅ Load current order info and set date/time
  useEffect(() => {
    const stored = localStorage.getItem("activeOrder");
    if (stored) {
      setActiveOrder(JSON.parse(stored));
    }

    // 🕒 Format current date and time
    const now = new Date();
    const formatted = now.toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short",
    });
    setCurrentDateTime(formatted);
  }, []);

  // ✅ Calculate billing totals
  const subTotal = orders.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  const gstAmount = (subTotal * gstPercent) / 100;
  const grandTotal = subTotal + gstAmount;

  // ✅ Save Bill / Send to Backend (future)
  const handleConfirmBill = async () => {
  const billData = {
    ...activeOrder,
    items: orders.map((item) => ({
      name: item.name,
      quantity: item.quantity,
      price: item.price,
      total: item.price * item.quantity,
    })),
    subTotal,
    gstPercent,
    gstAmount,
    grandTotal,
    billDate: new Date().toISOString(),
  };

  try {
    const res = await axios.post("/billing", billData);
    console.log("✅ Bill saved successfully:", res.data);
    alert("✅ Bill saved to database successfully!");
    clearOrders();
    localStorage.removeItem("activeOrder");
  } catch (error) {
    console.error("❌ Error saving bill:", error);
    alert("⚠️ Failed to save bill!");
  }
};


  const handlePrint = () => {
    window.print();
  };

  return (
    
    
<div
  className="billing-container"
  style={{
    backgroundImage: `url(${process.env.PUBLIC_URL}/images/Billing.jpg)`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    // backgroundRepeat: "no-repeat",
    
  }}
>      <h2>🧾 Final Billing</h2>

      {activeOrder ? (
        <div className="bill-info">
          <p><strong>👤 Customer:</strong> {activeOrder.customerName}</p>
          <p><strong>🍽️ Table No:</strong> {activeOrder.tableNo}</p>
          {activeOrder.orderNote && (
            <p><strong>📝 Note:</strong> {activeOrder.orderNote}</p>
          )}
          {/* 🕒 Date & Time */}
          <p><strong>📅 Date & Time:</strong> {currentDateTime}</p>
        </div>
      ) : (
        <p className="no-order-warning">⚠️ No active order found!</p>
      )}

      {orders.length === 0 ? (
        <p style={{ color: "red", fontWeight: "bold", textAlign: "center" }}>No items in bill.</p>
      ) : (
        <>
          <table className="bill-table">
            <thead>
              <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((item) => (
                <tr key={item.itemId}>
                  <td>{item.name}</td>
                  <td>{item.quantity}</td>
                  <td>₹{item.price}</td>
                  <td>₹{item.price * item.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="bill-summary">
            <p>Subtotal: <strong>₹{subTotal.toFixed(2)}</strong></p>
            <p>GST ({gstPercent}%): <strong>₹{gstAmount.toFixed(2)}</strong></p>
            <h4>Grand Total: ₹{grandTotal.toFixed(2)}</h4>
          </div>

          <div className="bill-actions">
            <button className="btn btn-success" onClick={handleConfirmBill}>
              💾 Confirm & Save Bill
            </button>
            <button className="btn btn-primary" onClick={handlePrint}>
              🖨️ Print Bill
            </button>
          </div>
        </>
      )}
    </div>
  );
}
