import React, { useState } from "react";
import axios from "../api/axiosConfig";
import './OrderList.css';
export default function OrderList() {
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const res = await axios.get("/orders");
    setOrders(res.data);
  };

  return (
    
    <div className="container mt-4">
      <h3>🧾 Orders</h3>
      <button className="btn btn-secondary mb-3" onClick={fetchOrders}>Load Orders</button>
      <center>
      <table className="table table-bordered">
        <thead className="table-dark">
          <tr>
            <th>ID</th><th>Table</th><th>Staff</th><th>Status</th><th>Total</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(o => (
            <tr key={o.orderId}>
              <td>{o.orderId}</td>
              <td>{o.table?.tableId}</td>
              <td>{o.staff?.firstName}</td>
              <td>{o.status}</td>
              <td>₹{o.totalAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </center>
    </div>
  );
}
