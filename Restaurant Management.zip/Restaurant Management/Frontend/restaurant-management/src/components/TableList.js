import React, { useState } from "react";
import axios from "../api/axiosConfig";
import './TableList.css';
export default function TableList() {
  const [tables, setTables] = useState([]);

  const fetchTables = async () => {
    const res = await axios.get("/tables");
    setTables(res.data);
  };

  return (
    <div className="container mt-4">
      <h3>🍽️ Restaurant Tables</h3>
      <button className="btn btn-success mb-3" onClick={fetchTables}>Load Tables</button>
      <table className="table table-hover">
        <thead className="table-dark">
          <tr>
            <th>ID</th><th>Capacity</th><th>Location</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          {tables.map(t => (
            <tr key={t.tableId}>
              <td>{t.tableId}</td>
              <td>{t.capacity}</td>
              <td>{t.location}</td>
              <td>{t.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
