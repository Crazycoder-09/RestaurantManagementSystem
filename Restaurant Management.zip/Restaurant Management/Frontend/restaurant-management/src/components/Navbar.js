import React, { useContext }from "react";

import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

import './Navbar.css';

export default function Navbar() {
  const { isAuthenticated, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-3">
      <div className="navbar-brand-container">
        <span className="navbar-brand">🍴 Hotel Management</span>
      </div>

      {/* ✅ Navigation Links */}
      <div className="navbar-nav ms-auto">
        {/* <Link className="nav-link" to="/staff">Staff</Link> */}
        {/* <Link className="nav-link" to="/tables">Tables</Link> */}
        {/* ✅ New Order tab added */}
                <Link className="nav-link" to="/new-order">Home</Link>
                <Link className="nav-link" to="/admin/bills">All Records</Link>
                <Link className="nav-link" to="/admin/menu">Admin</Link>
                <Link className="nav-link" to="/admin/orders">Orders</Link>

                {localStorage.getItem("isAuthenticated") === "true" && (
  <button
    className="btn btn-sm btn-danger ms-3"
    onClick={() => {
      localStorage.removeItem("isAuthenticated");
      window.location.href = "/login";
    }}
  >
    Logout
  </button>
)}

        {/* <Link className="nav-link" to="/new-order">New Order</Link>
        <Link className="nav-link" to="/menu">Menu</Link>
        <Link className="nav-link" to="/Order">Order</Link>
        <Link className="nav-link" to="/billing">Billing</Link> */}

        {/* <Link className="nav-link" to="/inventory">Inventory</Link> */}

        

        {/* <Link className="nav-link" to="/orders">Orders</Link> */}
        {/* <Link className="nav-link" to="/transactions">Transactions</Link> */}
      </div>
    </nav>
  );
}
