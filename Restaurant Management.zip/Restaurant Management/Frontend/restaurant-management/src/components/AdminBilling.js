import React, { useEffect, useState } from "react";
import axios from "../api/axiosConfig";
import "./AdminBilling.css";

export default function AdminBilling() {
  const [bills, setBills] = useState([]);

  useEffect(() => {
    const fetchBills = async () => {
      try {
        const res = await axios.get("/billing");
              console.log("📦 Bills fetched:", res.data);

        setBills(res.data);
      } catch (error) {
        console.error("❌ Error fetching bills:", error);
      }
    };
    fetchBills();
  }, []);

  return (
    <div className="admin-billing-container">
      <h2>📜 All Saved Bills</h2>

      {bills.length === 0 ? (
        <p>No bills found yet.</p>
      ) : (
        <table className="admin-bill-table">
          <thead>
            <tr>
              <th>Bill ID</th>
              <th>Customer</th>
              <th>Table</th>
              <th>Subtotal</th>
              <th>GST</th>
              <th>Grand Total</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {bills.map((bill) => (
              <tr key={bill.billId}>
                <td>{bill.billId}</td>
                <td>{bill.customerName}</td>
                <td>{bill.tableNo}</td>
                <td>₹{bill.subTotal.toFixed(2)}</td>
                <td>{bill.gstPercent}%</td>
                <td className="grand-total">₹{bill.grandTotal.toFixed(2)}</td>
                <td>
                  {new Date(bill.billDate).toLocaleString("en-IN", {
                    dateStyle: "short",
                    timeStyle: "short",
                  })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
