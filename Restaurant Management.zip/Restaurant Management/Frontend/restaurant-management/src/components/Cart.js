import React from "react";
import "./Cart.css";

export default function Cart({ cart, onQuantityChange, onRemove }) {
  // Calculate total amount
  const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  return (
    <div className="cart mt-4">
      <h4>🛒 Cart</h4>

      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          {cart.map((item) => (
            <div key={item.itemId} className="cart-item">
              <img
                src={item.imageUrl || "https://via.placeholder.com/50"}
                alt={item.name}
                className="cart-image"
              />

              <div className="cart-info">
                <div className="cart-details">
                  <span className="cart-name">{item.name}</span>
                  <span className="cart-price">₹{item.price}</span>
                </div>

                <div className="cart-actions">
                  <button
                    className="btn btn-sm btn-outline-secondary"
                    onClick={() =>
                      onQuantityChange(item.itemId, item.quantity - 1)
                    }
                    disabled={item.quantity <= 1}
                  >
                    ➖
                  </button>

                  <span className="cart-qty">{item.quantity}</span>

                  <button
                    className="btn btn-sm btn-outline-secondary"
                    onClick={() =>
                      onQuantityChange(item.itemId, item.quantity + 1)
                    }
                  >
                    ➕
                  </button>

                  <button
                    className="btn btn-sm btn-danger ms-2"
                    onClick={() => onRemove(item.itemId)}
                  >
                    ❌
                  </button>
                </div>
              </div>
            </div>
          ))}

          <h5 className="cart-total">Total: ₹{total}</h5>
        </>
      )}
    </div>
  );
}
