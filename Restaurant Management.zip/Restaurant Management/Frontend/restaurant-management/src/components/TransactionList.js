import React, { useState } from "react";
import axios from "../api/axiosConfig";
import './TransactionList.css';
export default function TransactionList() {
  const [transactions, setTransactions] = useState([]);

  const fetchTransactions = async () => {
    const res = await axios.get("/transactions");
    setTransactions(res.data);
  };

  return (
    <div className="container mt-4">
      <h3>💳 Transaction Records</h3>
      <button className="btn btn-dark mb-3" onClick={fetchTransactions}>Load Transactions</button>
      <center>
      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th><th>Order</th><th>Payment</th><th>Amount</th><th>Tip</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map(t => (
            <tr key={t.transactionId}>
              <td>{t.transactionId}</td>
              <td>{t.order?.orderId}</td>
              <td>{t.paymentMethod}</td>
              <td>₹{t.amountPaid}</td>
              <td>₹{t.tipAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </center>
    </div>
  );
}
