import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import "./Login.css";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    if (username === "admin" && password === "admin123") {
      login(); // ✅ updates context + localStorage
      navigate("/admin/menu");
    } else {
      alert("Invalid credentials!");
    }
  };

  return (
    <div className="login-container"
    style={{
    backgroundImage: `url(${process.env.PUBLIC_URL}/images/Login.jpg)`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    // backgroundRepeat: "no-repeat",
    
  }}>
      <h2>🔐 Admin Login</h2>
      <form onSubmit={handleLogin}>
        <div className="mb-3">
          <label>Username:</label>
          <input
            type="text"
            className="form-control"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label>Password:</label>
          <input
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary w-100">
          Login
        </button>
      </form>
    </div>
  );
}
